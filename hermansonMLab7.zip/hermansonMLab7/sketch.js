let array1 = [];
let array2 = [];
let array3 = [];

function setup() {
  createCanvas(400, 400);
  background(100)
  for(let x=0;x<5;x++){
    array1.push(int(random(0,25)))
    array2.push(int(random(26,50)))
    
  }
  console.log("array1:",array1)
  console.log("array2:",array2)
  
  array3=array1.concat(array2)
  console.log("array3:",array3)

  let random1= random(array1)
  let random2= random(array2)
  let random3= random(array3)
  text("array1: " + array1.join(","), 130,120);
  text("array2: " + array2.join(","), 130,130);
  text("random 1: " + random1,130,140);
  text("random 2: " + random2,130,150);
  text("random 1&2: " + random3,130,160);

}

