//cat likes to play, eye top left and move the mouse to move the lasers

let AAAAAH = 0;
let LOL = 100;
let xD = 5;

function setup() {
  createCanvas(400, 400);
  background(220);
  colorMode(RGB,100)
  frameRate(30)
}

function draw() {
  
  background(50)


  strokeWeight(xD)
  stroke(LOL,AAAAAH,AAAAAH)
  line(mouseX,mouseY,pmouseX,pmouseY)
  
  stroke(AAAAAH,LOL,AAAAAH)
  line(pow(mouseX,1.1),pow(mouseY,1.1),pow(pmouseX,1.1),pow(pmouseY,1.1))
  
  //eye
  
  strokeWeight(1)
  stroke(0)
  circle(10,10,40)
  
  strokeWeight(5)
  stroke(25,50,LOL)
  line(sqrt(mouseX),sqrt(mouseY),sqrt(pmouseX),sqrt(pmouseY))
  
  //paw 1 
  
  stroke(0)
  line(0,400,mouseX,mouseY)
  
  stroke(0)
  strokeWeight(1)
  circle(mouseX,mouseY,50)
  
  
  //paw 2 
  
  
  strokeWeight(5)
  line(0,400,pow(mouseX,1.1),pow(mouseY,1.1))
  
  strokeWeight(1)
  circle(pow(mouseX,1.1),pow(mouseY,1.1),50)
  

  
}