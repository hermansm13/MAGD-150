let things = []
let yChange;
let y;

function setup() {
  createCanvas(400, 400);
  
  for(let x = 100; x<400; x += 50){
    things.push(x);
  }
  console.log(things)
  y=1
  yChange = (1)
}

function draw() {
  
  y = y+yChange
  
  background(220);

  for (let x = 10; x<400;x += 30 ){
  circle(x,y,things[0])
   
    if(y>height){
      y = 0
    }
    
    things[0] = mouseY
  }
 

}