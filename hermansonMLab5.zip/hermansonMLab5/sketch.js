let d;
let dChange;

function setup() {
  createCanvas(400, 400);
  
  d = (0)
  dChange =(1)
}

function draw() {
  background(220);
  
  for(let x= 20; x < 400; x += 20){
    line( x,50, x, 350)
  }
  
  if(mouseIsPressed){
    fill(255)
  }
  if(keyIsPressed){
    fill(0)
  }
  
  d = d + dChange
  circle(200,200,d)
  
  if(d >= 150){
    d = d * -1;
  }
  

}