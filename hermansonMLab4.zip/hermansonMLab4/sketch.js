let x;
let y;
let xChange; 
let yChange;

function setup() {
  createCanvas(400, 400);
   
  x = random(0,400)
  y = random(0,400)
  xChange = random(-5,5);
  yChange = random(-5,5);

}

function draw() {
  y = y-yChange
  x = x-xChange
  background(220);
  circle(x,y,40)
  
  if(x>400){
  x = random(0,400)
  y = random(0,400)
  xChange = random(-5,5);
  yChange = random(-5,5);
  }
  
  if(x<0){
  x = random(0,400)
  y = random(0,400)
  xChange = random(-5,5);
  yChange = random(-5,5);
    
  }
  
  if(y<0){
  x = random(0,400)
  y = random(0,400)
  xChange = random(-5,5);
  yChange = random(-5,5);
    
  }
  
  if(y>400){
  x = random(0,400)
  y = random(0,400)
  xChange = random(-5,5);
  yChange = random(-5,5);
    
  }
  
  
}