function setup() {
  createCanvas(256, 256);
  background(220);
}

function draw() {
  
  //red balloon
  fill(255,0,0)
  curve(-200,512,128,128,128,128,456,512)
  triangle(128,128,134,134,122,134)
  
  noFill()
  bezier(128,134,80,200,200,80,128,180)
  
  //orange balloon
  fill(255,150,100)
  curve (-300,520,64,64,64,64,556,520)
  triangle(64,64,57,74,74,74)
  
  noFill()
  bezier(64,74,30,200,150,200,68,120)
  
  //green balloon
  fill(0,255,0)
  curve(-200,600,200,200,200,200,456,600)
  triangle(200,200,210,210,190,210)
  
  noFill()
  bezier(200,210,180,300,300,300,200,256)
  
  //blue balloon
  fill(0,0,255)
  curve(-220,460,180,60,180,60,580,460)
  triangle(180,60,190,70,170,70)
  
  noFill()
  bezier(180,70,105,170,250,120,180,180)
}